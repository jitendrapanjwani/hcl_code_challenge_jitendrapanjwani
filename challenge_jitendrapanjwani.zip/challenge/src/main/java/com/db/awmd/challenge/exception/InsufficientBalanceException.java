package com.db.awmd.challenge.exception;

public class InsufficientBalanceException extends Exception {

}
