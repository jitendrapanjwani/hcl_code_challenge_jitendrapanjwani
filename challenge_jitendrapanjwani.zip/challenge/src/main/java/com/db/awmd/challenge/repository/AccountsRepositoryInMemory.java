package com.db.awmd.challenge.repository;

import java.math.BigDecimal;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.db.awmd.challenge.domain.Account;
import com.db.awmd.challenge.exception.DuplicateAccountIdException;
import com.db.awmd.challenge.exception.InsufficientBalanceException;
import com.db.awmd.challenge.exception.InvalidAccountException;
import com.db.awmd.challenge.service.NotificationService;


@Repository
public class AccountsRepositoryInMemory implements AccountsRepository {

  private final Map<String, Account> accounts = new ConcurrentHashMap<>();
  @Autowired
  public NotificationService notificationService;

  @Override
  public void createAccount(Account account) throws DuplicateAccountIdException {
    Account previousAccount = accounts.putIfAbsent(account.getAccountId(), account);
    if (previousAccount != null) {
      throw new DuplicateAccountIdException(
        "Account id " + account.getAccountId() + " already exists!");
    }
  }

  @Override
  public Account getAccount(String accountId) throws InvalidAccountException {
	  if (accounts.get(accountId) == null) {
		  throw new InvalidAccountException("Account with " + accountId + " do not exists!");
	  }
	  
    return accounts.get(accountId);
  }

  @Override
  public void clearAccounts() {
    accounts.clear();
  }
  
  
  private void debit(Account fromAccount, BigDecimal amount) {
      synchronized(fromAccount.getAccountLockObject()) {
    	  fromAccount.setBalance(fromAccount.getBalance().subtract(amount));
      }
  }

  private void credit(Account toAccount, BigDecimal amount) {
      synchronized(toAccount.getAccountLockObject()) {
    	  toAccount.setBalance(toAccount.getBalance().add(amount));
      }
  }

  
  @Override
  public String doTransaction(Account fromAccount, Account toAccount , BigDecimal amount) {
	 
	  boolean validityCheck=true;
	  String returnVal=null;
	    try {
	    	this.getAccount(fromAccount.getAccountId());
	    	this.getAccount(toAccount.getAccountId());
	    	
	    } catch (InvalidAccountException invalidAcexp) {
	    	validityCheck=false;
	    	returnVal= "Incorrect account details";
	    	
	    }
	    
	    try {
	    	
	    	if (amount.compareTo(fromAccount.getBalance()) > 0) {
	    		throw new InsufficientBalanceException();
	    	}
	    } catch (InsufficientBalanceException ibe) {
	    	validityCheck=false;
	    	returnVal= "The account " + fromAccount.getAccountId()+ " has insufficient funds";
	      
	    }
	    if (validityCheck) {
	    	this.debit(fromAccount, amount); 
	    	this.credit(toAccount, amount); 
	    	notificationService.notifyAboutTransfer(fromAccount, "Your account has been debited with " + amount);
	    	notificationService.notifyAboutTransfer(toAccount, "Your account has been Credit with " + amount);
	    	returnVal = "Transaction completed successfully";
	    	
	    }
	      
	    return returnVal;
  }

}
