package com.db.awmd.challenge.exception;

import lombok.extern.java.Log;

public class InvalidAccountException extends Exception {
	
	public	InvalidAccountException(String message){
		super(message);
	}

}
